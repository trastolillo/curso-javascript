
let resultado;

resultado = 20 + 30 * 2;

resultado = ( 20 + 30 ) * 2;

// 20% de descuento en tu carrito de compras
resultado = (20 + 30 + 40 + 50 + 60 ) * .2;

resultado = (20 + 30) * 1.16;

console.log(resultado);