

let puntaje = 5;

puntaje -= 3;

console.log(puntaje);