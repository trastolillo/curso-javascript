const producto = 'Tablet';

// No se pueden reasignar
// producto = "Monitor";

console.log(producto);


const precio  = 20;
console.log(precio);