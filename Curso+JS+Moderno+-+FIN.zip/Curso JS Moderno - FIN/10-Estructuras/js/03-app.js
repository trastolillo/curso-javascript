// Operador Mayor que y menor que

const dinero = 300;
const totalAPagar = 300;

if( dinero >= totalAPagar ) {
    console.log('Si podemos pagar');
} else {
    console.log('Fondos Insuficientes');
}