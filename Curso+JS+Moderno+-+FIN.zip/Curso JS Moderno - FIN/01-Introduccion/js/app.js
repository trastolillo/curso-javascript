console.log('Hola');
console.log('Mundo');


function hola() {
    console.log('ok');
    console.log('Hola'); 
    console.log('Mundo');
}