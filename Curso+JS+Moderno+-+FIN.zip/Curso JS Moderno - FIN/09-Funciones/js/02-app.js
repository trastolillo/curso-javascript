// Declaración de Función ( Function Declaration )
sumar();
function sumar() {
    console.log( 2 + 2);
}



// Expresión de Función (Function Expression)
sumar2();
const sumar2 = function() {
    console.log( 3 + 3);
}
