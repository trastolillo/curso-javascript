// Declaración de Función ( Function Declaration )
function sumar() {
    console.log( 2 + 2);
}

sumar();
sumar();
sumar();

// Expresión de Función (Function Expression)
const sumar2 = function() {
    console.log( 3 + 3);
}

sumar2();