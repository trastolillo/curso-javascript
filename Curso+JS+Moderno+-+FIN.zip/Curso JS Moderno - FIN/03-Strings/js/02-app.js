const producto = 'Monitor 20 Pulgadas';

console.log(producto);

// Conocer la cantidad de letras de la cadena de texto
console.log(producto.length);



// console.log(producto.indexOf('Tablet'));


console.log(producto.includes('Tablet'));
console.log(producto.includes('Monitor'));
console.log(producto.includes('monitor'));
